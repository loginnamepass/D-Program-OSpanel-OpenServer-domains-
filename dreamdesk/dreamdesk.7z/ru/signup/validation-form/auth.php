<?php
	$login = filter_var(trim($_POST['login']),
		FILTER_SANITIZE_STRING);
	$pass = filter_var(trim($_POST['pass']),
		FILTER_SANITIZE_STRING);

	$mysql = new mysqli('localhost','g977619u_signup','K%g866P7','g977619u_signup');

	$result = $mysql->query("SELECT * FROM `register` WHERE `login` = '$login' AND '$pass'");
	$user = $result->fetch_assoc();
	if(count($user) == 0) {
		echo "Такий користувач не існує, перевірте логін та пароль!";
		exit();
	}

	setcookie('user', $user['username'], time() + 3600, "/");

	$mysql->close();

	header('location: /dreamdesk/dreamdesk');
?>