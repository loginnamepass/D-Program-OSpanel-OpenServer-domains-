<?php 
	$login = filter_var(trim($_POST['login']),
		FILTER_SANITIZE_STRING);
	$name = filter_var(trim($_POST['name']),
		FILTER_SANITIZE_STRING);
	$pass = filter_var(trim($_POST['pass']),
		FILTER_SANITIZE_STRING);

	if(mb_strlen($login) < 5 || mb_strlen($login) > 50){
		echo "lol";
		exit();
	} else if(mb_strlen($name) < 2 || mb_strlen($name) > 50){
		echo "lol2";
		exit();
	} else if(mb_strlen($pass) < 8 || mb_strlen($pass) > 50){
		echo "lol3";
		exit();
	}

	$mysql = new mysqli('dreamdesk','mysql','mysql','signup');
	$mysql->query("INSERT INTO `register`(`username`, `password`, `login`)
	VALUES('$login','$pass','$name')");
	$mysql->close();

	header('location: /');
?>