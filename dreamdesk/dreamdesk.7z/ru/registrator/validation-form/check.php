<?php 
	$login = filter_var(trim($_POST['login']),
		FILTER_SANITIZE_STRING);
	$name = filter_var(trim($_POST['name']),
		FILTER_SANITIZE_STRING);
	$pass = filter_var(trim($_POST['pass']),
		FILTER_SANITIZE_STRING);

	if(mb_strlen($login) < 2 || mb_strlen($login) > 50){
		echo "Ім'я повинне містити не менше двох символів!";
		exit();
	} else if(mb_strlen($name) < 2 || mb_strlen($name) > 50){
		echo "Логін повинне містити не менше двох символів!";
		exit();
	} else if(mb_strlen($pass) < 8 || mb_strlen($pass) > 50){
		echo "Пароль повинне містити не менше восьми символів!";
		exit();
	}

	$mysql = new mysqli('localhost','g977619u_signup','K%g866P7','g977619u_signup');
	$mysql->query("INSERT INTO `register`(`username`, `password`, `login`)
	VALUES('$login','$pass','$name')");
	$mysql->close();

	header('location: /');
?>